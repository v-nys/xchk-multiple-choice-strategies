from django.apps import AppConfig


class MultipleChoiceStrategiesConfig(AppConfig):
    name = 'xchk_multiple_choice_strategies'
