# Generated from MultipleChoice.g4 by ANTLR 4.8
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .MultipleChoiceParser import MultipleChoiceParser
else:
    from MultipleChoiceParser import MultipleChoiceParser

# This class defines a complete listener for a parse tree produced by MultipleChoiceParser.
class MultipleChoiceListener(ParseTreeListener):

    # Enter a parse tree produced by MultipleChoiceParser#multiplechoice.
    def enterMultiplechoice(self, ctx:MultipleChoiceParser.MultiplechoiceContext):
        pass

    # Exit a parse tree produced by MultipleChoiceParser#multiplechoice.
    def exitMultiplechoice(self, ctx:MultipleChoiceParser.MultiplechoiceContext):
        pass


    # Enter a parse tree produced by MultipleChoiceParser#qa.
    def enterQa(self, ctx:MultipleChoiceParser.QaContext):
        pass

    # Exit a parse tree produced by MultipleChoiceParser#qa.
    def exitQa(self, ctx:MultipleChoiceParser.QaContext):
        pass



del MultipleChoiceParser